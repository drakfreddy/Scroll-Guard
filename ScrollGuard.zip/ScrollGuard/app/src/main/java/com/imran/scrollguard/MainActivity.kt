package com.imran.scrollguard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var usage: TextView
    private lateinit var note: TextView
    private lateinit var input: EditText

    private fun tv(text: String, sp: Float, bold: Boolean = false, topDp: Int = 12) =
        TextView(this).apply {
            this.text = text
            textSize = sp
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            val d = resources.displayMetrics.density
            setPadding(0, (topDp * d).toInt(), 0, 0)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (20 * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        root.addView(tv("Scroll Guard", 28f, bold = true, topDp = 0))
        root.addView(tv("Daily scroll limit shared across TikTok, Instagram and X.", 14f))

        status = tv("", 16f, bold = true, topDp = 20)
        root.addView(status)

        usage = tv("", 40f, bold = true, topDp = 8)
        root.addView(usage)

        root.addView(tv("Daily limit (swipes)", 14f, topDp = 24))
        input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "e.g. 300"
        }
        root.addView(input)

        root.addView(Button(this).apply {
            text = "Save limit"
            setOnClickListener { saveLimit() }
        })

        note = tv("", 13f)
        root.addView(note)

        root.addView(android.widget.Switch(this).apply {
            text = "Debug mode (counter also shows why a swipe was counted or ignored)"
            isChecked = Store.isDebug(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Store.setDebug(this@MainActivity, on) }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = (20 * d).toInt()
        })

        root.addView(Button(this).apply {
            text = "Open Accessibility settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = (24 * d).toInt()
        })

        root.addView(tv(
            "Tip: lowering the limit works instantly. Raising it only takes effect tomorrow, " +
                    "so you can't bargain with yourself mid-scroll.\n\n" +
                    "If Android says \"Restricted setting\": Settings > Apps > Scroll Guard > ⋮ > " +
                    "Allow restricted settings, then enable the service again.",
            13f, topDp = 20
        ))

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val on = serviceOn()
        status.text = if (on) "● Active" else "○ Not active - enable Scroll Guard in Accessibility settings"
        status.setTextColor(if (on) 0xFF2E7D32.toInt() else 0xFFC62828.toInt())
        usage.text = "${Store.count(this)} / ${Store.limit(this)}"
        val next = Store.nextLimit(this)
        val cur = Store.limit(this)
        input.setText(next.toString())
        note.text = if (next > cur) "Limit of $next starts tomorrow." else ""
    }

    private fun saveLimit() {
        val v = input.text.toString().toIntOrNull()
        if (v == null || v < 1 || v > 10000) {
            note.text = "Enter a number between 1 and 10000."
            return
        }
        val now = Store.setLimit(this, v)
        refresh()
        note.text = if (now) "Limit set to $v." else "Limit of $v starts tomorrow."
    }

    private fun serviceOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        return s.split(':').any { it.startsWith("$packageName/") }
    }
}
