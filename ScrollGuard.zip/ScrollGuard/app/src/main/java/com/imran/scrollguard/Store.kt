package com.imran.scrollguard

import android.content.Context
import java.time.LocalDate

/** Daily scroll count + limit, shared across all tracked apps. Resets at midnight. */
object Store {
    const val DEFAULT_LIMIT = 300

    private fun prefs(c: Context) =
        c.applicationContext.getSharedPreferences("scroll_guard", Context.MODE_PRIVATE)

    private fun rollover(c: Context) {
        val p = prefs(c)
        val today = LocalDate.now().toString()
        if (p.getString("date", "") != today) {
            val limit = p.getInt("limit", DEFAULT_LIMIT)
            p.edit()
                .putString("date", today)
                .putInt("count", 0)
                .putInt("limit", p.getInt("nextLimit", limit)) // raised limits kick in on a new day
                .apply()
        }
    }

    fun count(c: Context): Int { rollover(c); return prefs(c).getInt("count", 0) }

    fun limit(c: Context): Int { rollover(c); return prefs(c).getInt("limit", DEFAULT_LIMIT) }

    fun nextLimit(c: Context): Int { rollover(c); return prefs(c).getInt("nextLimit", limit(c)) }

    fun increment(c: Context): Int {
        rollover(c)
        val p = prefs(c)
        val n = p.getInt("count", 0) + 1
        p.edit().putInt("count", n).apply()
        return n
    }

    /**
     * Lowering the limit applies immediately. Raising it only applies from tomorrow,
     * so you can't talk yourself into more scrolls in the moment.
     * Returns true if the new limit is active right now.
     */
    fun setLimit(c: Context, value: Int): Boolean {
        rollover(c)
        val p = prefs(c)
        val current = p.getInt("limit", DEFAULT_LIMIT)
        return if (value <= current) {
            p.edit().putInt("limit", value).putInt("nextLimit", value).apply()
            true
        } else {
            p.edit().putInt("nextLimit", value).apply()
            false
        }
    }

    fun isDebug(c: Context): Boolean = prefs(c).getBoolean("debug", false)

    fun setDebug(c: Context, on: Boolean) {
        prefs(c).edit().putBoolean("debug", on).apply()
    }
}
