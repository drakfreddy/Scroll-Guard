package com.imran.scrollguard

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.SystemClock
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class ScrollGuardService : AccessibilityService() {

    companion object {
        // Apps that count toward the shared daily limit.
        private val TRACKED = setOf(
            "com.zhiliaoapp.musically",   // TikTok
            "com.ss.android.ugc.trill",   // TikTok (Asia builds)
            "com.instagram.android",      // Instagram
            "com.instagram.lite",         // Instagram Lite
            "com.twitter.android"         // X
        )

        // TUNING: a new swipe is counted when scroll events pause for this long.
        // Too many counts per swipe -> raise it. Fast swipes getting merged -> lower it.
        private const val GAP_MS = 350L

        // While scrolling continuously (e.g. a long X feed fling), count again every this many ms.
        private const val LONG_SCROLL_MS = 1500L
    }

    private var overlay: TextView? = null
    private var currentPkg: String? = null
    private var lastEventAt = 0L
    private var lastCountedAt = 0L
    private var lastBlockAt = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val pkg = event.packageName?.toString() ?: return

        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                // Ignore system UI, keyboards etc. so the counter doesn't flicker.
                if (pkg.contains("systemui") || pkg.contains("inputmethod") ||
                    pkg.contains("keyboard") || pkg.contains("honeyboard")
                ) return
                currentPkg = pkg
                if (pkg in TRACKED) {
                    if (Store.count(this) >= Store.limit(this)) block() else showOverlay()
                } else {
                    hideOverlay()
                }
            }

            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                if (pkg !in TRACKED) return
                if (currentPkg != pkg) { currentPkg = pkg }
                onScroll(event)
            }
        }
    }

    private fun onScroll(event: AccessibilityEvent) {
        if (Store.count(this) >= Store.limit(this)) { block(); return }

        // Ignore clearly horizontal scrolls (Instagram carousels, story taps etc.)
        if (Build.VERSION.SDK_INT >= 28) {
            if (abs(event.scrollDeltaX) > abs(event.scrollDeltaY)) return
        }

        val now = SystemClock.uptimeMillis()
        val newSwipe = now - lastEventAt > GAP_MS
        val longScroll = now - lastCountedAt > LONG_SCROLL_MS
        lastEventAt = now

        if (newSwipe || longScroll) {
            lastCountedAt = now
            val n = Store.increment(this)
            showOverlay()
            if (n >= Store.limit(this)) block()
        }
    }

    private fun block() {
        hideOverlay()
        val now = SystemClock.uptimeMillis()
        if (now - lastBlockAt < 1000) return
        lastBlockAt = now
        Toast.makeText(
            this,
            "Daily scroll limit reached (${Store.limit(this)}). See you tomorrow!",
            Toast.LENGTH_LONG
        ).show()
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    // ---------- Overlay (top-left, just under the status bar / clock) ----------

    private fun showOverlay() {
        try {
            if (overlay == null) createOverlay()
            val count = Store.count(this)
            val limit = Store.limit(this)
            overlay?.apply {
                text = "$count / $limit"
                (background as? GradientDrawable)?.setColor(
                    if (count >= limit * 0.9) 0xCCC62828.toInt() else 0x99000000.toInt()
                )
                visibility = android.view.View.VISIBLE
            }
        } catch (_: Exception) {
        }
    }

    private fun hideOverlay() {
        overlay?.visibility = android.view.View.GONE
    }

    private fun createOverlay() {
        val d = resources.displayMetrics.density
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setPadding((8 * d).toInt(), (3 * d).toInt(), (8 * d).toInt(), (3 * d).toInt())
            background = GradientDrawable().apply {
                cornerRadius = 12 * d
                setColor(0x99000000.toInt())
            }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (12 * d).toInt()
            y = statusBarHeight() + (4 * d).toInt()
        }
        (getSystemService(WINDOW_SERVICE) as WindowManager).addView(tv, lp)
        overlay = tv
    }

    private fun statusBarHeight(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else (24 * resources.displayMetrics.density).toInt()
    }

    private fun removeOverlay() {
        try {
            overlay?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }
        } catch (_: Exception) {
        }
        overlay = null
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        removeOverlay()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        removeOverlay()
        super.onDestroy()
    }
}
