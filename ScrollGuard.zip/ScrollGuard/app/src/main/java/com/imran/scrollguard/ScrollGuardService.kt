package com.imran.scrollguard

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class ScrollGuardService : AccessibilityService() {

    companion object {
        private const val X_PKG = "com.twitter.android"

        // Apps that count toward the shared daily limit.
        private val TRACKED = setOf(
            "com.zhiliaoapp.musically",   // TikTok
            "com.ss.android.ugc.trill",   // TikTok (Asia builds)
            "com.instagram.android",      // Instagram
            "com.instagram.lite",         // Instagram Lite
            X_PKG                         // X
        )

        // A new swipe is counted when scroll events pause for this long.
        private const val GAP_MS = 350L

        // While scrolling continuously, count again every this many ms.
        private const val LONG_SCROLL_MS = 1500L

        // FEED FILTER: feeds (TikTok For You/Following, Reels, Instagram home) show only
        // 1-2 items at a time. Chat lists, inboxes, comments and profile grids show many.
        // A scroll counts only if at most this many items are visible on screen.
        private const val MAX_VISIBLE_ITEMS = 2
        private const val MAX_VISIBLE_ITEMS_X = 4   // X timelines show a few posts at once
    }

    private var overlay: TextView? = null
    private var lastEventAt = 0L
    private var lastCountedAt = 0L
    private var lastBlockAt = 0L
    private var note = ""

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val pkg = event.packageName?.toString() ?: return

        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                // Ignore system UI, keyboards etc. so the counter doesn't flicker.
                if (pkg.contains("systemui") || pkg.contains("inputmethod") ||
                    pkg.contains("keyboard") || pkg.contains("honeyboard")
                ) return
                if (pkg in TRACKED) showOverlay() else hideOverlay()
            }

            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                if (pkg in TRACKED) onScroll(pkg, event)
            }
        }
    }

    private fun onScroll(pkg: String, event: AccessibilityEvent) {
        // 1) Ignore clearly horizontal scrolls (carousels, stories, tabs).
        if (Build.VERSION.SDK_INT >= 28 && abs(event.scrollDeltaX) > abs(event.scrollDeltaY)) {
            note = "ignored: sideways"
            showOverlay()
            return
        }

        // 2) Feed filter: how many items are visible in the scrolled list?
        val from = event.fromIndex
        val to = event.toIndex
        val visible = if (from >= 0 && to >= from) to - from + 1 else -1
        val maxVisible = if (pkg == X_PKG) MAX_VISIBLE_ITEMS_X else MAX_VISIBLE_ITEMS
        if (visible > maxVisible) {
            note = "ignored: list ($visible items)"
            showOverlay()
            return
        }
        note = if (visible < 0) "counted (items ?)" else "counted ($visible item)"

        // 3) Limit reached: only feed scrolling is blocked, so chats still work.
        if (Store.count(this) >= Store.limit(this)) {
            block()
            return
        }

        // 4) Count one swipe per burst of scroll events.
        val now = SystemClock.uptimeMillis()
        val newSwipe = now - lastEventAt > GAP_MS
        val longScroll = now - lastCountedAt > LONG_SCROLL_MS
        lastEventAt = now

        if (newSwipe || longScroll) {
            lastCountedAt = now
            val n = Store.increment(this)
            showOverlay()
            if (n >= Store.limit(this)) block()
        } else {
            showOverlay()
        }
    }

    private fun block() {
        val now = SystemClock.uptimeMillis()
        if (now - lastBlockAt < 1000) return
        lastBlockAt = now
        Toast.makeText(
            this,
            "Daily scroll limit reached (${Store.limit(this)}). See you tomorrow!",
            Toast.LENGTH_LONG
        ).show()
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    // ---------- Overlay (top-left, just under the status bar / clock) ----------

    private fun showOverlay() {
        try {
            if (overlay == null) createOverlay()
            val count = Store.count(this)
            val limit = Store.limit(this)
            overlay?.apply {
                text = if (Store.isDebug(this@ScrollGuardService) && note.isNotEmpty())
                    "$count / $limit  ·  $note" else "$count / $limit"
                (background as? GradientDrawable)?.setColor(
                    if (count >= limit * 0.9) 0xCCC62828.toInt() else 0x99000000.toInt()
                )
                visibility = View.VISIBLE
            }
        } catch (_: Exception) {
        }
    }

    private fun hideOverlay() {
        overlay?.visibility = View.GONE
    }

    private fun createOverlay() {
        val d = resources.displayMetrics.density
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setPadding((8 * d).toInt(), (3 * d).toInt(), (8 * d).toInt(), (3 * d).toInt())
            background = GradientDrawable().apply {
                cornerRadius = 12 * d
                setColor(0x99000000.toInt())
            }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (12 * d).toInt()
            y = statusBarHeight() + (4 * d).toInt()
        }
        (getSystemService(WINDOW_SERVICE) as WindowManager).addView(tv, lp)
        overlay = tv
    }

    private fun statusBarHeight(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else (24 * resources.displayMetrics.density).toInt()
    }

    private fun removeOverlay() {
        try {
            overlay?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }
        } catch (_: Exception) {
        }
        overlay = null
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        removeOverlay()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        removeOverlay()
        super.onDestroy()
    }
}
